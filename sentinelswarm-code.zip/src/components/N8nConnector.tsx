import { useEffect, useRef, useState } from "react";
import { Loader2, PlugZap, CheckCircle2, AlertTriangle, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "sentinelswarm.n8n.webhook";
const DEFAULT_WEBHOOK = "https://sathwik082.app.n8n.cloud/webhook-test/agent-swarm";

type Status = "idle" | "sending" | "live" | "error";

export function N8nConnector({
  payload,
  scenarioId,
  trigger,
}: {
  payload: string;
  scenarioId: string;
  /** Increment to fire a dispatch (e.g. when the demo run starts). */
  trigger: number;
}) {
  const [url, setUrl] = useState(DEFAULT_WEBHOOK);
  const [status, setStatus] = useState<Status>("idle");
  const [detail, setDetail] = useState<string>("");
  const [result, setResult] = useState<string>("");
  const lastTrigger = useRef(trigger);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) setUrl(saved);
    else localStorage.setItem(STORAGE_KEY, DEFAULT_WEBHOOK);
  }, []);

  const send = async (target: string) => {
    if (!target) {
      setStatus("error");
      setDetail("Paste your n8n webhook URL first.");
      return;
    }
    setStatus("sending");
    setDetail("");
    setResult("");
    try {
      const res = await fetch("/api/public/n8n", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          webhookUrl: target,
          payload: {
            source: "sentinelswarm-web",
            scenarioId,
            payload,
            receivedAt: new Date().toISOString(),
          },
        }),
      });
      const body = (await res.json()) as {
        ok?: boolean;
        status?: number;
        error?: string;
        latencyMs?: number;
        data?: unknown;
      };
      if (!res.ok || !body.ok) {
        setStatus("error");
        setDetail(body.error ?? `Workflow replied ${body.status ?? res.status}`);
        setResult(typeof body.data === "string" ? body.data : JSON.stringify(body.data, null, 2));
        return;
      }
      setStatus("live");
      setDetail(`Workflow answered in ${body.latencyMs ?? 0} ms`);
      setResult(
        typeof body.data === "string" ? body.data : JSON.stringify(body.data ?? {}, null, 2),
      );
    } catch (error) {
      setStatus("error");
      setDetail(error instanceof Error ? error.message : "Request failed");
    }
  };

  // Fire automatically when the live run starts, if a URL is saved.
  useEffect(() => {
    if (trigger === lastTrigger.current) return;
    lastTrigger.current = trigger;
    const saved = localStorage.getItem(STORAGE_KEY) || DEFAULT_WEBHOOK;
    if (saved) void send(saved);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trigger]);

  return (
    <div className="panel p-4">
      <div className="flex items-center gap-2">
        <PlugZap className="size-4 text-primary" />
        <p className="font-display text-sm font-semibold">Connect your n8n workflow</p>
        <span
          className={cn(
            "ml-auto flex items-center gap-1.5 font-mono text-[11px]",
            status === "live" && "text-success",
            status === "error" && "text-destructive",
            status === "sending" && "text-primary",
            status === "idle" && "text-muted-foreground",
          )}
        >
          {status === "sending" && <Loader2 className="size-3 animate-spin" />}
          {status === "live" && <CheckCircle2 className="size-3" />}
          {status === "error" && <AlertTriangle className="size-3" />}
          {status === "idle"
            ? "not connected"
            : status === "sending"
              ? "sending…"
              : status === "live"
                ? "live"
                : "failed"}
        </span>
      </div>

      <p className="mt-2 text-xs text-muted-foreground">
        Paste the webhook URL from your n8n trigger node. Every run sends the selected payload
        there; the built-in demo keeps playing if n8n can't be reached.
      </p>

      <div className="mt-3 flex flex-col gap-2 sm:flex-row">
        <input
          value={url}
          onChange={(e) => {
            setUrl(e.target.value);
            localStorage.setItem(STORAGE_KEY, e.target.value.trim());
          }}
          placeholder="https://your-n8n.app.n8n.cloud/webhook-test/scam-check"
          className="min-w-0 flex-1 rounded-md border border-border bg-background/70 px-3 py-2 font-mono text-xs text-foreground outline-none placeholder:text-muted-foreground/70 focus:border-primary"
        />
        <Button
          variant="secondary"
          onClick={() => void send(url.trim())}
          disabled={status === "sending"}
        >
          <Send className="size-4" /> Send test
        </Button>
      </div>

      {detail && (
        <p
          className={cn(
            "mt-2 font-mono text-[11px]",
            status === "error" ? "text-destructive" : "text-muted-foreground",
          )}
        >
          {detail}
        </p>
      )}

      {result && (
        <pre className="mt-2 max-h-40 overflow-auto rounded-md border border-border bg-background/60 p-3 font-mono text-[11px] leading-relaxed text-foreground/90">
          {result}
        </pre>
      )}
    </div>
  );
}
