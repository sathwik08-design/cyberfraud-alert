import { NODE_META, type LogLine, type NodeId } from "@/lib/pipeline";
import { cn } from "@/lib/utils";
import { useEffect, useRef } from "react";

export function AgentConsole({
  node,
  logs,
  running,
  tone = "primary",
}: {
  node: NodeId;
  logs: LogLine[];
  running: boolean;
  tone?: "primary" | "accent";
}) {
  const lines = logs.filter((l) => l.node === node);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [lines.length]);

  return (
    <div className="panel flex h-64 flex-col overflow-hidden">
      <div className="flex items-center gap-2 border-b border-border px-4 py-2.5">
        <span
          className={cn(
            "size-2 rounded-full",
            running
              ? tone === "accent"
                ? "bg-accent animate-pulse"
                : "bg-primary animate-pulse"
              : lines.length
                ? "bg-success"
                : "bg-muted-foreground/40",
          )}
        />
        <p className="font-display text-sm font-semibold">{NODE_META[node].label}</p>
        <span className="ml-auto font-mono text-[11px] text-muted-foreground">
          {lines.length} events
        </span>
      </div>
      <div className="flex-1 space-y-2 overflow-y-auto px-4 py-3 font-mono text-[12px] leading-relaxed">
        {lines.length === 0 && (
          <p className="text-muted-foreground">waiting for orchestrator dispatch…</p>
        )}
        {lines.map((l, i) => (
          <p key={i} className="animate-rise text-foreground/90">
            <span className={cn(tone === "accent" ? "text-accent" : "text-primary")}>
              {String(l.t).padStart(2, "0")}·
            </span>{" "}
            {l.text}
          </p>
        ))}
        <div ref={endRef} />
      </div>
    </div>
  );
}
