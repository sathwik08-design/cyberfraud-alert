import type { Scenario } from "@/lib/pipeline";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  PolarAngleAxis,
  PolarGrid,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const tooltipStyle = {
  background: "var(--color-card)",
  border: "1px solid var(--color-border)",
  borderRadius: "10px",
  fontSize: 12,
  color: "var(--color-foreground)",
} as const;

export function SignalRadar({ scenario }: { scenario: Scenario }) {
  return (
    <ResponsiveContainer width="100%" height={230}>
      <RadarChart data={scenario.signals} outerRadius="72%">
        <PolarGrid stroke="var(--color-border)" />
        <PolarAngleAxis
          dataKey="label"
          tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
        />
        <Radar
          dataKey="score"
          stroke="var(--color-chart-1)"
          fill="var(--color-chart-1)"
          fillOpacity={0.35}
        />
        <Tooltip contentStyle={tooltipStyle} />
      </RadarChart>
    </ResponsiveContainer>
  );
}

export function IntelBars({ scenario }: { scenario: Scenario }) {
  return (
    <ResponsiveContainer width="100%" height={230}>
      <BarChart data={scenario.intel} layout="vertical" margin={{ left: 8, right: 18 }}>
        <CartesianGrid horizontal={false} stroke="var(--color-border)" />
        <XAxis
          type="number"
          domain={[0, 100]}
          tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
        />
        <YAxis
          type="category"
          dataKey="source"
          width={116}
          tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
        />
        <Tooltip contentStyle={tooltipStyle} />
        <Bar dataKey="score" radius={[0, 6, 6, 0]} barSize={16}>
          {scenario.intel.map((d, i) => (
            <Cell
              key={i}
              fill={d.score > 70 ? "var(--color-chart-3)" : "var(--color-chart-4)"}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function ConfidenceLine({
  series,
}: {
  series: { step: number; score: number }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={230}>
      <LineChart data={series} margin={{ left: -12, right: 12 }}>
        <CartesianGrid stroke="var(--color-border)" />
        <XAxis
          dataKey="step"
          tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
          label={{
            value: "pipeline event",
            position: "insideBottom",
            offset: -2,
            fill: "var(--color-muted-foreground)",
            fontSize: 11,
          }}
        />
        <YAxis
          domain={[0, 100]}
          tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
        />
        <Tooltip contentStyle={tooltipStyle} />
        <Line
          type="monotone"
          dataKey="score"
          stroke="var(--color-chart-2)"
          strokeWidth={2.5}
          dot={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
