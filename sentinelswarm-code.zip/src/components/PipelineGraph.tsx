import { NODE_META, type NodeId, type NodeStatus } from "@/lib/pipeline";
import {
  Webhook,
  Network,
  Globe,
  Cpu,
  GitMerge,
  ShieldCheck,
  Database,
  Ban,
  Check,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";

const ICONS: Record<NodeId, React.ComponentType<{ className?: string }>> = {
  input: Webhook,
  orchestrator: Network,
  research: Globe,
  analysis: Cpu,
  merge: GitMerge,
  validator: ShieldCheck,
  log: Database,
  action: Ban,
};

function Node({
  id,
  status,
  count,
}: {
  id: NodeId;
  status: NodeStatus;
  count: number;
}) {
  const Icon = ICONS[id];
  const meta = NODE_META[id];
  return (
    <div
      className={cn(
        "relative flex w-full flex-col gap-1 rounded-xl border bg-card/80 p-3 text-left transition-all duration-300 backdrop-blur-sm",
        status === "idle" && "border-border opacity-55",
        status === "running" && "border-primary/70 animate-pulse-node",
        status === "done" && "border-success/50",
        status === "blocked" && "border-muted text-muted-foreground opacity-60",
      )}
    >
      <div className="flex items-center gap-2">
        <span
          className={cn(
            "flex size-8 shrink-0 items-center justify-center rounded-lg",
            status === "running" && "bg-primary/20 text-primary",
            status === "done" && "bg-success/15 text-success",
            (status === "idle" || status === "blocked") && "bg-muted text-muted-foreground",
          )}
        >
          <Icon className="size-4" />
        </span>
        <div className="min-w-0">
          <p className="truncate font-display text-sm font-semibold">{meta.label}</p>
          <p className="truncate text-[11px] text-muted-foreground">{meta.role}</p>
        </div>
        <span className="ml-auto">
          {status === "running" && <Loader2 className="size-4 animate-spin text-primary" />}
          {status === "done" && <Check className="size-4 text-success" />}
        </span>
      </div>
      <div className="flex items-center justify-between text-[10px] uppercase tracking-widest text-muted-foreground">
        <span>
          {status === "running"
            ? "working"
            : status === "done"
              ? "complete"
              : status === "blocked"
                ? "skipped"
                : "queued"}
        </span>
        <span className="font-mono">{count} evt</span>
      </div>
    </div>
  );
}

function Connector({ active }: { active: boolean }) {
  return (
    <div className="flex h-6 items-center justify-center">
      <svg width="2" height="24" viewBox="0 0 2 24" aria-hidden="true">
        <line
          x1="1"
          y1="0"
          x2="1"
          y2="24"
          strokeWidth="2"
          strokeDasharray="4 4"
          className={cn(active ? "stroke-primary animate-dash" : "stroke-border")}
        />
      </svg>
    </div>
  );
}

export function PipelineGraph({
  statuses,
  counts,
}: {
  statuses: Record<NodeId, NodeStatus>;
  counts: Record<NodeId, number>;
}) {
  const live = (id: NodeId) => statuses[id] === "running" || statuses[id] === "done";

  return (
    <div className="mx-auto max-w-xl">
      <Node id="input" status={statuses.input} count={counts.input} />
      <Connector active={live("orchestrator")} />
      <Node id="orchestrator" status={statuses.orchestrator} count={counts.orchestrator} />
      <div className="flex h-6 items-center justify-center gap-2">
        <div
          className={cn(
            "h-px flex-1 rounded",
            live("research") ? "bg-primary" : "bg-border",
          )}
        />
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
          parallel
        </span>
        <div
          className={cn("h-px flex-1 rounded", live("analysis") ? "bg-primary" : "bg-border")}
        />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Node id="research" status={statuses.research} count={counts.research} />
        <Node id="analysis" status={statuses.analysis} count={counts.analysis} />
      </div>
      <Connector active={live("merge")} />
      <Node id="merge" status={statuses.merge} count={counts.merge} />
      <Connector active={live("validator")} />
      <Node id="validator" status={statuses.validator} count={counts.validator} />
      <div className="flex h-6 items-center justify-center gap-2">
        <div className={cn("h-px flex-1 rounded", live("log") ? "bg-primary" : "bg-border")} />
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
          gate passed
        </span>
        <div className={cn("h-px flex-1 rounded", live("action") ? "bg-primary" : "bg-border")} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Node id="log" status={statuses.log} count={counts.log} />
        <Node id="action" status={statuses.action} count={counts.action} />
      </div>
    </div>
  );
}
