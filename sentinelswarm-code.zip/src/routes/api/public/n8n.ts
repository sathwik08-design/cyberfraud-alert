import { createFileRoute } from "@tanstack/react-router";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Max-Age": "86400",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

/**
 * Server-side proxy so the browser can hand a payload to an n8n webhook
 * without running into CORS or exposing the workflow URL in page source.
 */
export const Route = createFileRoute("/api/public/n8n")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders }),

      POST: async ({ request }) => {
        let body: { webhookUrl?: unknown; payload?: unknown };
        try {
          body = (await request.json()) as typeof body;
        } catch {
          return json({ ok: false, error: "Invalid JSON body" }, 400);
        }

        const envUrl = process.env["N8N_WEBHOOK_URL"];
        const raw = typeof body.webhookUrl === "string" ? body.webhookUrl.trim() : "";
        const target = raw || envUrl || "";

        if (!target) {
          return json({ ok: false, error: "No n8n webhook URL configured" }, 400);
        }

        let url: URL;
        try {
          url = new URL(target);
        } catch {
          return json({ ok: false, error: "That doesn't look like a valid URL" }, 400);
        }
        if (url.protocol !== "https:" && url.protocol !== "http:") {
          return json({ ok: false, error: "Only http/https URLs are allowed" }, 400);
        }

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000);
        const started = Date.now();

        try {
          const res = await fetch(url.toString(), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body.payload ?? {}),
            signal: controller.signal,
          });

          const text = await res.text();
          let data: unknown = text;
          try {
            data = JSON.parse(text);
          } catch {
            /* keep raw text */
          }

          if (!res.ok) {
            console.error(`n8n webhook failed [${res.status}]: ${text}`);
          }

          return json({
            ok: res.ok,
            status: res.status,
            latencyMs: Date.now() - started,
            data,
          });
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          console.error(`n8n webhook request error: ${message}`);
          return json({ ok: false, error: message, latencyMs: Date.now() - started }, 502);
        } finally {
          clearTimeout(timeout);
        }
      },
    },
  },
});
