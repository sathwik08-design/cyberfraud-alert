import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  AudioLines,
  Link2,
  Play,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  Timer,
  Zap,
  Boxes,
  GaugeCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { PipelineGraph } from "@/components/PipelineGraph";
import { AgentConsole } from "@/components/AgentConsole";
import { N8nConnector } from "@/components/N8nConnector";
import { ConfidenceLine, IntelBars, SignalRadar } from "@/components/ThreatCharts";
import {
  buildSteps,
  SCENARIOS,
  type LogLine,
  type NodeId,
  type NodeStatus,
} from "@/lib/pipeline";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SentinelSwarm — Stop AI Voice Scams & Phishing Links" },
      {
        name: "description",
        content:
          "A multi-agent security console that detects fake AI voice calls and phishing links on your phone before any money leaves your account.",
      },
      { property: "og:title", content: "SentinelSwarm — AI Voice Scam & Phishing Defence" },
      {
        property: "og:description",
        content:
          "Watch orchestrator, research, analysis and validator agents work in parallel to block scams in real time.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const NODES: NodeId[] = [
  "input",
  "orchestrator",
  "research",
  "analysis",
  "merge",
  "validator",
  "log",
  "action",
];

function Index() {
  const [scenarioId, setScenarioId] = useState(SCENARIOS[0]!.id);
  const scenario = SCENARIOS.find((s) => s.id === scenarioId)!;
  const steps = useMemo(() => buildSteps(scenario), [scenario]);

  const [cursor, setCursor] = useState(-1); // index of last executed step
  const [running, setRunning] = useState(false);
  const [dispatchCount, setDispatchCount] = useState(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const reset = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    setRunning(false);
    setCursor(-1);
  }, []);

  useEffect(() => reset(), [scenarioId, reset]);
  useEffect(() => () => void (timer.current && clearTimeout(timer.current)), []);

  useEffect(() => {
    if (!running) return;
    const next = cursor + 1;
    if (next >= steps.length) {
      setRunning(false);
      return;
    }
    timer.current = setTimeout(() => setCursor(next), steps[next]!.delay);
    return () => void (timer.current && clearTimeout(timer.current));
  }, [running, cursor, steps]);

  const logs: LogLine[] = steps
    .slice(0, cursor + 1)
    .map((s, i) => ({ t: i + 1, node: s.node, text: s.text }));

  const statuses = useMemo(() => {
    const out = {} as Record<NodeId, NodeStatus>;
    for (const n of NODES) {
      const first = steps.findIndex((s) => s.node === n);
      const last = steps.map((s) => s.node).lastIndexOf(n);
      if (first === -1 || cursor < first) out[n] = "idle";
      else if (cursor >= last) out[n] = "done";
      else out[n] = "running";
    }
    if (scenario.verdict === "allow" && out.action !== "idle") out.action = "blocked";
    return out;
  }, [steps, cursor, scenario.verdict]);

  const counts = useMemo(() => {
    const out = {} as Record<NodeId, number>;
    for (const n of NODES) out[n] = logs.filter((l) => l.node === n).length;
    return out;
  }, [logs]);

  const progress = cursor < 0 ? 0 : Math.round(((cursor + 1) / steps.length) * 100);
  const finished = cursor >= steps.length - 1;
  const liveScore = Math.round(scenario.severity * (progress / 100));
  const confidenceSeries = steps
    .slice(0, cursor + 1)
    .map((_, i) => ({
      step: i + 1,
      score: Math.round((scenario.severity * (i + 1)) / steps.length),
    }));

  const researchRunning = statuses.research === "running";
  const analysisRunning = statuses.analysis === "running";

  return (
    <main className="relative min-h-screen overflow-hidden">
      <div className="pointer-events-none absolute inset-0 grid-lines" aria-hidden="true" />

      {/* Top nav */}
      <header className="sticky top-0 z-30 border-b border-border/60 bg-background/80 backdrop-blur">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3.5">
          <a href="#top" className="flex items-center gap-2.5">
            <ShieldAlert className="size-5 text-destructive" />
            <span className="font-display text-lg font-bold tracking-tight">SentinelSwarm</span>
          </a>
          <div className="flex items-center gap-2 sm:gap-6">
            <a
              href="#pipeline"
              className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground sm:block"
            >
              How it works
            </a>
            <a
              href="#threats"
              className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground sm:block"
            >
              See demo
            </a>
            <Button variant="outline" size="sm" asChild>
              <a href="#verdict">Verdict gate</a>
            </Button>
            <Button
              size="sm"
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (finished) setCursor(-1);
                setDispatchCount((c) => c + 1);
                setRunning(true);
              }}
            >
              Try it free
            </Button>
          </div>
        </nav>
      </header>

      {/* Hero */}
      <section id="top" className="relative isolate overflow-hidden">
        <div
          className="absolute inset-0 -z-10 bg-gradient-to-b from-background/20 via-transparent to-background/80"
          aria-hidden="true"
        />
        <div className="mx-auto max-w-4xl px-5 pt-20 pb-24 text-center sm:pt-24 sm:pb-32">
          <p className="font-mono text-xs tracking-[0.2em] text-muted-foreground uppercase">
            DVPS03 · Cybersecurity &amp; Digital Safety
          </p>
          <h1 className="mt-8 font-display text-5xl leading-[0.92] font-bold tracking-tight sm:text-[5.5rem]">
            <span className="block text-foreground">Your AI Guardian</span>
            <span className="mt-1 block text-fraud-gradient">Against Fraud</span>
          </h1>
          <p className="mx-auto mt-8 max-w-2xl text-lg text-muted-foreground sm:text-xl">
            Learns your habits. Spots what's off.{" "}
            <span className="font-semibold text-foreground">
              Explains it in plain language — not jargon.
            </span>
          </p>
          <p className="mt-5 text-sm text-muted-foreground">
            Free to try · No account needed · Takes 30 seconds
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="bg-destructive text-destructive-foreground shadow-glow hover:bg-destructive/90"
              onClick={() => {
                if (finished) setCursor(-1);
                setDispatchCount((c) => c + 1);
                setRunning(true);
              }}
              disabled={running}
            >
              {running ? "Swarm running…" : "Try the Demo"} <ArrowRight className="size-4" />
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="#threats">
                <Play className="size-4" /> See a live threat
              </a>
            </Button>
          </div>
          <div className="mt-6 flex justify-center">
            <Button variant="secondary" size="lg" asChild>
              <a href="#pipeline">See how it works</a>
            </Button>
          </div>

          <dl className="mx-auto mt-14 grid max-w-lg grid-cols-3 gap-4">
            {[
              { k: "1.9s", v: "median decision" },
              { k: "2×", v: "parallel agents" },
              { k: "0", v: "auto-block on doubt" },
            ].map((s) => (
              <div key={s.v}>
                <dt className="font-display text-2xl font-bold text-primary">{s.k}</dt>
                <dd className="text-xs text-muted-foreground">{s.v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>


      {/* Scenario picker */}
      <section id="threats" className="relative mx-auto max-w-6xl px-5 pt-4 pb-6">
        <h2 className="text-xl font-semibold">1 · Choose an incoming threat</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Each one is a real webhook payload the swarm ingests.
        </p>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          {SCENARIOS.map((s) => (
            <button
              key={s.id}
              onClick={() => setScenarioId(s.id)}
              className={cn(
                "panel p-4 text-left transition-all hover:border-primary/60",
                s.id === scenarioId && "border-primary shadow-glow",
              )}
            >
              <span className="flex items-center gap-2 text-primary">
                {s.kind === "voice" ? (
                  <AudioLines className="size-4" />
                ) : (
                  <Link2 className="size-4" />
                )}
                <span className="text-[11px] uppercase tracking-widest">{s.kind}</span>
              </span>
              <p className="mt-2 font-display text-sm font-semibold">{s.title}</p>
              <p className="mt-1 text-xs text-muted-foreground">{s.subtitle}</p>
            </button>
          ))}
        </div>
        <div className="panel mt-4 flex flex-wrap items-center gap-3 px-4 py-3 font-mono text-xs text-muted-foreground">
          <span className="text-primary">payload »</span>
          <span className="break-all">{scenario.payload}</span>
        </div>
        <div className="mt-4">
          <N8nConnector
            payload={scenario.payload}
            scenarioId={scenario.id}
            trigger={dispatchCount}
          />
        </div>
      </section>

      {/* Pipeline + live consoles */}
      <section id="pipeline" className="relative mx-auto max-w-6xl px-5 py-8">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="text-xl font-semibold">2 · Watch the agents work</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Every node lights up as it processes the payload.
            </p>
          </div>
          <div className="min-w-56">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>pipeline progress</span>
              <span className="font-mono">{progress}%</span>
            </div>
            <Progress value={progress} className="mt-1.5 h-2" />
          </div>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="panel p-5">
            <PipelineGraph statuses={statuses} counts={counts} />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <AgentConsole node="research" logs={logs} running={researchRunning} />
            <AgentConsole node="analysis" logs={logs} running={analysisRunning} tone="accent" />
            <AgentConsole
              node="orchestrator"
              logs={logs}
              running={statuses.orchestrator === "running"}
            />
            <AgentConsole
              node="validator"
              logs={logs}
              running={statuses.validator === "running"}
              tone="accent"
            />
          </div>
        </div>
      </section>

      {/* Charts */}
      <section className="relative mx-auto max-w-6xl px-5 py-8">
        <h2 className="text-xl font-semibold">3 · Evidence the swarm collected</h2>
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          <div className="panel p-4">
            <p className="font-display text-sm font-semibold">Risk signal profile</p>
            <p className="mb-2 text-xs text-muted-foreground">Analysis Agent, on-device</p>
            <SignalRadar scenario={scenario} />
          </div>
          <div className="panel p-4">
            <p className="font-display text-sm font-semibold">Threat intel sources</p>
            <p className="mb-2 text-xs text-muted-foreground">Research Agent, external feeds</p>
            <IntelBars scenario={scenario} />
          </div>
          <div className="panel p-4">
            <p className="font-display text-sm font-semibold">Severity build-up</p>
            <p className="mb-2 text-xs text-muted-foreground">Merged score per event</p>
            <ConfidenceLine
              series={confidenceSeries.length ? confidenceSeries : [{ step: 0, score: 0 }]}
            />
          </div>
        </div>
      </section>

      {/* Verdict */}
      <section id="verdict" className="relative mx-auto max-w-6xl px-5 py-8">
        <h2 className="text-xl font-semibold">4 · Validator verdict</h2>
        <div className="mt-4 grid gap-4 lg:grid-cols-[0.9fr_1.1fr]">
          <div
            className={cn(
              "panel flex flex-col justify-between p-6",
              finished && scenario.verdict === "block" && "border-destructive/60",
              finished && scenario.verdict === "allow" && "border-success/60",
            )}
          >
            <div className="flex items-center gap-3">
              {scenario.verdict === "block" ? (
                <ShieldAlert
                  className={cn("size-8", finished ? "text-destructive" : "text-muted-foreground")}
                />
              ) : (
                <ShieldCheck
                  className={cn("size-8", finished ? "text-success" : "text-muted-foreground")}
                />
              )}
              <div>
                <p className="text-xs uppercase tracking-widest text-muted-foreground">
                  final decision
                </p>
                <p className="font-display text-2xl font-bold">
                  {!finished
                    ? "Awaiting gate…"
                    : scenario.verdict === "block"
                      ? "Blocked — scam confirmed"
                      : "Allowed — false positive stopped"}
                </p>
              </div>
            </div>
            <div className="mt-6">
              <div className="flex items-end justify-between">
                <span className="text-xs text-muted-foreground">severity score</span>
                <span className="font-display text-3xl font-bold text-primary">
                  {liveScore}
                  <span className="text-base text-muted-foreground">/100</span>
                </span>
              </div>
              <Progress value={liveScore} className="mt-2 h-2.5" />
              <p className="mt-2 text-xs text-muted-foreground">
                Action threshold is 85. Anything below is logged, never auto-blocked.
              </p>
            </div>
          </div>
          <div className="panel p-6">
            <p className="font-display text-sm font-semibold">Remediation &amp; notifications</p>
            <ul className="mt-4 space-y-3">
              {scenario.actions.map((a) => {
                const shown = logs.some((l) => l.text === a);
                return (
                  <li
                    key={a}
                    className={cn(
                      "flex items-start gap-3 rounded-lg border border-border px-3 py-2.5 text-sm transition-opacity",
                      shown ? "opacity-100" : "opacity-40",
                    )}
                  >
                    <GaugeCircle
                      className={cn("mt-0.5 size-4", shown ? "text-primary" : "text-muted-foreground")}
                    />
                    <span>{a}</span>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </section>

      {/* Advantages */}
      <section className="relative mx-auto max-w-6xl px-5 py-10">
        <h2 className="text-xl font-semibold">Why this architecture wins</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          {[
            {
              icon: Timer,
              t: "Parallel execution",
              d: "Research and analysis run at the same time instead of one after the other, cutting mean time to respond.",
            },
            {
              icon: Boxes,
              t: "Decoupled agents",
              d: "Each agent keeps its own memory, so one noisy task can never pollute another's reasoning.",
            },
            {
              icon: Zap,
              t: "Verification gate",
              d: "A standalone validator approves or rejects remediation, so nothing destructive fires on a false alarm.",
            },
          ].map((c) => (
            <div key={c.t} className="panel p-5">
              <c.icon className="size-5 text-primary" />
              <p className="mt-3 font-display text-base font-semibold">{c.t}</p>
              <p className="mt-1.5 text-sm text-muted-foreground">{c.d}</p>
            </div>
          ))}
        </div>
        <p className="mt-8 text-center text-xs text-muted-foreground">
          Demonstration interface — agent results are scripted sample data for presentation.
        </p>
      </section>
    </main>
  );
}
