export type NodeId =
  | "input"
  | "orchestrator"
  | "research"
  | "analysis"
  | "merge"
  | "validator"
  | "log"
  | "action";

export type NodeStatus = "idle" | "running" | "done" | "blocked";

export interface LogLine {
  t: number;
  node: NodeId;
  text: string;
}

export interface Signal {
  label: string;
  score: number;
}

export interface Scenario {
  id: string;
  kind: "voice" | "link" | "file";
  title: string;
  subtitle: string;
  payload: string;
  severity: number;
  verdict: "block" | "allow" | "review";
  research: string[];
  analysis: string[];
  validator: string[];
  actions: string[];
  signals: Signal[];
  intel: { source: string; verdict: string; score: number }[];
}

export const SCENARIOS: Scenario[] = [
  {
    id: "voice",
    kind: "voice",
    title: "AI voice call — “Dad, send money now”",
    subtitle: "Incoming call, 42s audio sample captured",
    payload:
      'Voice call from +91 98•••• 4471 — "Hi dad, I lost my phone, transfer ₹45,000 to this UPI id right now."',
    severity: 96,
    verdict: "block",
    research: [
      "Querying caller-ID reputation feed for +91 98••••4471",
      "AbuseIPDB / scam-number registry: 214 reports in 30 days",
      "Voice clone corpus match: sample overlaps a known TTS model fingerprint",
      "UPI handle appears on 3 mule-account watchlists",
    ],
    analysis: [
      "Spectral analysis: breathing gaps absent in 91% of speech frames",
      "Pitch jitter 0.4% (human baseline 1.8–4.2%) → synthetic voice",
      "Emotional urgency markers: 7 money words in first 20 seconds",
      "Caller never appeared in your 12-month call history",
    ],
    validator: [
      "Cross-checking research + analysis confidence agreement: 0.94",
      "Severity 96 exceeds action threshold (85)",
      "False-positive policy check: no contact-book match → passed",
      "Remediation approved with user confirmation gate",
    ],
    actions: [
      "Call flagged and recording quarantined",
      "Payment shortcut to that UPI id temporarily frozen",
      "Alert written to incident DB + email to trusted contact",
    ],
    signals: [
      { label: "Voice synthesis", score: 97 },
      { label: "Caller reputation", score: 88 },
      { label: "Urgency pressure", score: 93 },
      { label: "Payment risk", score: 95 },
      { label: "History match", score: 12 },
    ],
    intel: [
      { source: "Scam-number registry", verdict: "214 reports", score: 91 },
      { source: "Voice clone corpus", verdict: "Model match", score: 97 },
      { source: "Mule account list", verdict: "Listed", score: 89 },
    ],
  },
  {
    id: "link",
    kind: "link",
    title: "SMS phishing link — bank “KYC update”",
    subtitle: "Link tapped from an unknown sender",
    payload: "hxxps://secure-kyc-update[.]icici-verify[.]top/login?ref=8821",
    severity: 92,
    verdict: "block",
    research: [
      "Domain registered 4 days ago via privacy proxy",
      "VirusTotal: 14 / 71 engines flag as phishing",
      "TLS certificate issued 3 days ago, no bank ownership chain",
      "Hosting IP shares subnet with 38 lookalike bank domains",
    ],
    analysis: [
      "Page clones ICICI login DOM with 96% structural similarity",
      "Form posts credentials to a different domain than it displays",
      "No official bank domain in your saved-app registry matches",
      "Link arrived from a sender never seen in your inbox",
    ],
    validator: [
      "Both agents agree: phishing, confidence 0.93",
      "Severity 92 exceeds action threshold (85)",
      "Whitelist check: domain not in trusted-bank allowlist",
      "Block approved — no destructive action required",
    ],
    actions: [
      "Link blocked before page load",
      "Sender reported to carrier spam feed",
      "Event logged; SOC-style digest queued",
    ],
    signals: [
      { label: "Domain age", score: 95 },
      { label: "Engine detections", score: 84 },
      { label: "Brand clone", score: 96 },
      { label: "Credential exfil", score: 90 },
      { label: "Sender trust", score: 8 },
    ],
    intel: [
      { source: "VirusTotal", verdict: "14/71 malicious", score: 84 },
      { source: "WHOIS", verdict: "4 days old", score: 95 },
      { source: "Certificate log", verdict: "No bank chain", score: 88 },
    ],
  },
  {
    id: "safe",
    kind: "link",
    title: "Delivery tracking link from a saved contact",
    subtitle: "Validator stops a false positive",
    payload: "https://track.bluedart.com/shipment/4417298331",
    severity: 34,
    verdict: "allow",
    research: [
      "Domain age: 24 years, registrant matches courier brand",
      "VirusTotal: 0 / 71 engines flag this URL",
      "Certificate chain valid and brand-owned",
      "No entries on phishing or mule watchlists",
    ],
    analysis: [
      "Sender is in your contacts with 3 years of history",
      "No credential form present on the destination page",
      "Message pattern matches normal courier notifications",
      "Heuristic engine raised a weak flag on the shortened path",
    ],
    validator: [
      "Research score 12 vs analysis flag 41 → disagreement detected",
      "Severity 34 below action threshold (85)",
      "False-positive guard engaged: no remediation executed",
      "Outcome downgraded to informational log only",
    ],
    actions: [
      "No block issued — link allowed",
      "Weak heuristic flag recorded for model tuning",
      "No alert sent to the user",
    ],
    signals: [
      { label: "Domain age", score: 6 },
      { label: "Engine detections", score: 0 },
      { label: "Brand clone", score: 9 },
      { label: "Credential exfil", score: 4 },
      { label: "Sender trust", score: 88 },
    ],
    intel: [
      { source: "VirusTotal", verdict: "0/71 clean", score: 4 },
      { source: "WHOIS", verdict: "24 years old", score: 6 },
      { source: "Contact graph", verdict: "Known sender", score: 8 },
    ],
  },
];

export interface Step {
  node: NodeId;
  text: string;
  delay: number;
}

/** Flattens a scenario into an ordered stream of log steps, with the
 *  research + analysis agents interleaved to show parallel execution. */
export function buildSteps(s: Scenario): Step[] {
  const steps: Step[] = [
    { node: "input", text: `Payload ingested: ${s.payload}`, delay: 500 },
    { node: "input", text: "Signature verified, forwarding to orchestrator", delay: 420 },
    { node: "orchestrator", text: "Intent classified: potential financial fraud", delay: 520 },
    {
      node: "orchestrator",
      text: "Fan-out → Research Agent + Analysis Agent (parallel)",
      delay: 480,
    },
  ];

  const rounds = Math.max(s.research.length, s.analysis.length);
  for (let i = 0; i < rounds; i++) {
    const r = s.research[i];
    const a = s.analysis[i];
    if (r) steps.push({ node: "research", text: r, delay: 430 });
    if (a) steps.push({ node: "analysis", text: a, delay: 430 });
  }

  steps.push(
    { node: "merge", text: "Joining both agent payloads into one context object", delay: 520 },
    { node: "merge", text: `Unified severity score computed: ${s.severity}/100`, delay: 460 },
  );
  s.validator.forEach((v) => steps.push({ node: "validator", text: v, delay: 480 }));
  s.actions.forEach((a, i) =>
    steps.push({ node: i === 0 ? "action" : i === 1 ? "log" : "action", text: a, delay: 450 }),
  );
  steps.push({ node: "log", text: "Run complete — audit trail sealed", delay: 400 });

  return steps;
}

export const NODE_META: Record<NodeId, { label: string; role: string }> = {
  input: { label: "Swarm Input", role: "Webhook ingest" },
  orchestrator: { label: "Orchestrator", role: "Intent + delegation" },
  research: { label: "Research Agent", role: "External threat intel" },
  analysis: { label: "Analysis Agent", role: "On-device telemetry" },
  merge: { label: "Merge Node", role: "Context unification" },
  validator: { label: "Validator", role: "Policy + confidence gate" },
  log: { label: "DB Log / Email", role: "Audit + notify" },
  action: { label: "Action / Remediation", role: "Block + isolate" },
};
